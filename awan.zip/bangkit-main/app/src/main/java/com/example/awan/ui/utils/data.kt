package com.example.awan.ui.utils

data class skinsEntity(
    var name: String,
    var desc: String,
    var cloud :String
)